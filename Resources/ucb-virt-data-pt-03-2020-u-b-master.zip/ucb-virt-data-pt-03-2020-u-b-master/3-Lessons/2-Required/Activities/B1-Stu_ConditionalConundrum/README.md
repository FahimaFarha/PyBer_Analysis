## The conditional puzzle

### Instructions

* Look through the examples and figure out what line will print.

* Do not run the code at first, see if you can follow the thought process and guess.
