## Cleaning Kickstarter

### Instructions

* The instructions for this activity are contained within the Jupyter Notebook.
