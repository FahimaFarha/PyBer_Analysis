# Bars Bar Chart

### Instructions

* Using the file provided as a starter, create a bar chart that matches the image provided.
