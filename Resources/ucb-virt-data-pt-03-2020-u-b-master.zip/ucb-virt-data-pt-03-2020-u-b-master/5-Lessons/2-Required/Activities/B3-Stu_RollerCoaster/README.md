# Coaster Speed

### Instructions

* Create a line chart with two plots using the following data...

* `Danger Drop: [9, 8, 90, 85, 80, 70, 70, 65, 55, 60, 70, 65, 50]`

* `RailGun: [75, 70, 60, 65, 60, 45, 55, 50, 40, 40, 35, 35, 30]`

* Both coasters are 120 seconds long and the speed was measured every 10 seconds.

* Apply styling and labels that match the image provided.
